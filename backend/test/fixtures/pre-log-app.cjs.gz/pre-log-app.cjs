"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.createApp = createApp;
const express_1 = __importDefault(require("express"));
const security_1 = require("./http/security");
const errors_1 = require("./http/errors");
const config_1 = require("./config");
const service_1 = require("./auth/service");
const routes_1 = require("./auth/routes");
const service_2 = require("./accounts/service");
const routes_2 = require("./accounts/routes");
const service_3 = require("./roles/service");
const routes_3 = require("./roles/routes");
const routes_4 = require("./audit/routes");
const middleware_1 = require("./authorization/middleware");
const routes_5 = require("./visitors/routes");
const private_routes_1 = require("./visitors/private-routes");
const service_4 = require("./visitors/service");
function createApp(release, options = {}) {
    const app = (0, express_1.default)();
    const authConfig = options.config && "jwtSecret" in options.config ? options.config : undefined;
    const auth = options.db && authConfig
        ? (0, service_1.createAuthService)({
            pool: options.db,
            config: authConfig,
            clock: options.clock ?? config_1.systemClock,
        })
        : undefined;
    (0, security_1.installSecurity)(app, options.config ?? { allowedOrigins: [], trustProxy: false });
    if (auth && options.db && options.analytics)
        app.use("/api/customer-access", (0, private_routes_1.visitorReadRoutes)((0, service_4.createVisitorService)(options.db, options.analytics.catalogue, options.clock ?? config_1.systemClock), auth));
    else
        app.use("/api/customer-access", () => {
            throw new errors_1.ApiError(503, "NOT_READY", "Dịch vụ chưa sẵn sàng");
        });
    if (options.analytics && options.config)
        app.use("/api/analytics", (0, routes_5.analyticsRoutes)(options.analytics, options.config, options.clock, release.releaseId));
    else
        app.use("/api/analytics", () => {
            throw new errors_1.ApiError(503, "NOT_READY", "Dịch vụ chưa sẵn sàng");
        });
    app.use((_req, res, next) => {
        res.setHeader("Cache-Control", "no-store");
        next();
    });
    app.use((req, res, next) => {
        if (process.env.NODE_ENV !== "production") {
            const start = performance.now();
            res.once("finish", () => console.log(`${req.method} ${req.path} ${res.statusCode} ${Math.round(performance.now() - start)}ms`));
        }
        next();
    });
    const endpoints = ["/api/health", "/api/version", "/api/demo"];
    app.use((req, res, next) => {
        if (endpoints.includes(req.path) && !["GET", "HEAD"].includes(req.method)) {
            res.setHeader("Allow", "GET, HEAD");
            res.status(405).json({ error: "Method not allowed" });
        }
        else
            next();
    });
    app.get("/api/health", (_req, res) => {
        res.json({ ok: true });
    });
    app.get("/api/ready", async (_req, res) => {
        if (!options.db || !options.config || !auth)
            throw new errors_1.ApiError(503, "NOT_READY", "Dịch vụ chưa sẵn sàng");
        const [schema] = await options.db.query("SELECT version,state FROM schema_migrations ORDER BY version");
        const [[master]] = await options.db.query("SELECT COUNT(*) n FROM users WHERE is_master=1 AND active=1 AND deleted_at IS NULL");
        if (schema.length !== 4 ||
            schema.some((row, index) => row.version !== index + 1 || row.state !== "complete") ||
            master.n !== 1)
            throw new errors_1.ApiError(503, "NOT_READY", "Dịch vụ chưa sẵn sàng");
        res.json({ ok: true });
    });
    if (auth && authConfig && options.db)
        app.use("/api/auth", (0, routes_1.authRoutes)({
            auth,
            config: authConfig,
            pool: options.db,
            clock: options.clock ?? config_1.systemClock,
        }));
    else
        app.use("/api/auth", () => {
            throw new errors_1.ApiError(503, "NOT_READY", "Dịch vụ chưa sẵn sàng");
        });
    if (auth && authConfig && options.db)
        app.use("/api/accounts", (0, routes_2.accountRoutes)((0, service_2.createAccountService)({ pool: options.db, clock: options.clock ?? config_1.systemClock }), auth, authConfig));
    else
        app.use("/api/accounts", () => {
            throw new errors_1.ApiError(503, "NOT_READY", "Dịch vụ chưa sẵn sàng");
        });
    if (auth && authConfig && options.db) {
        const roles = (0, service_3.createRoleService)({ pool: options.db, clock: options.clock ?? config_1.systemClock });
        app.use("/api/roles", (0, routes_3.roleRoutes)(roles, auth, authConfig));
        app.get("/api/permissions", (0, middleware_1.authenticate)(auth), (0, middleware_1.requirePermission)("permission.view"), async (req, res) => res.json(await roles.listPermissions(req.auth)));
        app.use("/api/audit", (0, routes_4.auditRoutes)(options.db, auth, options.clock ?? config_1.systemClock));
    }
    else
        app.use(["/api/roles", "/api/permissions", "/api/audit"], () => {
            throw new errors_1.ApiError(503, "NOT_READY", "Dịch vụ chưa sẵn sàng");
        });
    app.get("/api/version", (_req, res) => {
        res.json({ releaseId: release.releaseId, sourceSha: release.sourceSha });
    });
    app.get("/api/demo", (_req, res) => {
        res.json({
            message: "Hello from BiBi Studio API",
            framework: "Express",
            items: ["React", "Express", "cPanel"],
        });
    });
    app.use((_req, res) => {
        res.status(404).json({ error: "Not found" });
    });
    app.use(errors_1.errorHandler);
    return app;
}
//# sourceMappingURL=app.js.map